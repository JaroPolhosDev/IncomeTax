﻿using AutoFixture;
using Customers_API.Controllers;
using Customers_API.Models;
using Customers_API.Repositories;
using Customers_API.Services;
using FluentAssertions;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace CustomersApi.UnitTests
{
    public class CustomersServiceTests
    {
        private readonly Mock<ICustomersRepository> _mockCustomersRepository;
        private readonly Mock<IValidator<Customer>> _mockValidator;
        private readonly ICustomersService _service;
        private readonly IFixture _fixture;

        public CustomersServiceTests()
        {
            _mockCustomersRepository = new Mock<ICustomersRepository>();
            _mockValidator = new Mock<IValidator<Customer>>();

            _service = new CustomersService(_mockCustomersRepository.Object, _mockValidator.Object);
            _fixture = new Fixture();
        }

        [Fact]
        public async Task CreateCustomerAsync_ValidCustomerDetails_CreatesCustomer()
        {
            CreateCustomerRequest request = _fixture.Create<CreateCustomerRequest>();

            Customer expectedCustomer = _fixture.Build<Customer>()
                                        .With(x => x.FirstName, request.FirstName)
                                        .With(x => x.LastName, request.LastName)
                                        .With(x => x.BirthDate, request.BirthDate)
                                        .With(x => x.AnnualIncome, request.AnnualIncome)
                                        .Create();
            ValidationResult validationPassed = _fixture.Build<ValidationResult>().With(X => X.Errors, new List<ValidationFailure>()).Create();

            _mockCustomersRepository.Setup(x => x.CreateCustomerAsync(request)).ReturnsAsync(expectedCustomer);
            _mockValidator.Setup(v => v.ValidateAsync(It.IsAny<IValidationContext>(), It.IsAny<CancellationToken>())).ReturnsAsync(new ValidationResult());

            var result = await _service.CreateCustomerAsync(request);

            result.Should().BeEquivalentTo(expectedCustomer);
        }

        [Fact]
        public async Task CreateCustomerAsync_InvalidCustomerDetails_CreatesCustomer()
        {
            CreateCustomerRequest request = _fixture.Create<CreateCustomerRequest>();

            _mockCustomersRepository.Setup(x => x.CreateCustomerAsync(request)).ThrowsAsync(new KeyNotFoundException());
            _mockValidator.Setup(v => v.ValidateAsync(It.IsAny<IValidationContext>(), It.IsAny<CancellationToken>())).ReturnsAsync(new ValidationResult());

            Func<Task> action = () => _service.CreateCustomerAsync(request);

            await action.Should().ThrowAsync<KeyNotFoundException>();
        }

        [Fact]
        public async Task GetCustomerById_ValidCustomerId_ReturnsCustomer()
        {
            var customerId = _fixture.Create<int>();
            var expected = _fixture.Create<Customer>();

            _mockCustomersRepository.Setup(x => x.GetCustomerByIdAsync(customerId)).ReturnsAsync(expected);

            var result = await _service.GetCustomerByIdAsync(customerId);

            result.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public async Task GetCustomerById_InvalidCustomerId_ReturnsNotFound()
        {
            var customerId = _fixture.Create<int>();

            _mockCustomersRepository.Setup(x => x.GetCustomerByIdAsync(customerId)).ThrowsAsync(new KeyNotFoundException());

            Func<Task> action = () => _service.GetCustomerByIdAsync(customerId);

            await action.Should().ThrowAsync<KeyNotFoundException>();
        }
    }
}
