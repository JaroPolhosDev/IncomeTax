﻿using AutoFixture;
using Customers_API.DataSource;
using Customers_API.Models;
using Customers_API.Repositories;
using Customers_API.Services;
using FluentAssertions.Common;
using FluentAssertions;
using FluentValidation;
using Moq;
using Xunit;

namespace CustomersApi.UnitTests
{
    public class CustomersRepositoryTests
    {
        private readonly Mock<ICustomersDataSource> _mockDataSource;
        private readonly ICustomersRepository _repository;
        private readonly IFixture _fixture;

        public CustomersRepositoryTests()
        {
            _mockDataSource = new Mock<ICustomersDataSource>();

            _repository = new CustomersRepository(_mockDataSource.Object );
            _fixture = new Fixture();
        }

        [Fact]
        public async Task CreateCustomerAsync_ValidCustomerDetails_CreatesCustomer()
        {
            CreateCustomerRequest request = _fixture.Create<CreateCustomerRequest>();

            Customer expectedCustomer = _fixture.Build<Customer>()
                                        .With(x => x.FirstName, request.FirstName)
                                        .With(x => x.LastName, request.LastName)
                                        .With(x => x.BirthDate, request.BirthDate)
                                        .With(x => x.AnnualIncome, request.AnnualIncome)
                                        .Create();

            _mockDataSource.Setup(x => x.CreateCustomerAsync(request)).ReturnsAsync(expectedCustomer);

            var result = await _repository.CreateCustomerAsync(request);

            result.Should().BeEquivalentTo(expectedCustomer);
        }

        [Fact]
        public async Task CreateCustomerAsync_InvalidCustomerDetails_CreatesCustomer()
        {
            CreateCustomerRequest request = _fixture.Create<CreateCustomerRequest>();

            _mockDataSource.Setup(x => x.CreateCustomerAsync(request)).ThrowsAsync(new KeyNotFoundException());

            Func<Task> action = () => _repository.CreateCustomerAsync(request);

            await action.Should().ThrowAsync<KeyNotFoundException>();
        }

        [Fact]
        public async Task GetCustomerById_ValidCustomerId_ReturnsCustomer()
        {
            var customerId = _fixture.Create<int>();
            var expected = _fixture.Create<Customer>();

            _mockDataSource.Setup(x => x.GetCustomerByIdAsync(customerId)).ReturnsAsync(expected);

            var result = await _repository.GetCustomerByIdAsync(customerId);

            result.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public async Task GetCustomerById_InvalidCustomerId_ReturnsNotFound()
        {
            var customerId = _fixture.Create<int>();

            _mockDataSource.Setup(x => x.GetCustomerByIdAsync(customerId)).ThrowsAsync(new KeyNotFoundException());

            Func<Task> action = () => _repository.GetCustomerByIdAsync(customerId);

            await action.Should().ThrowAsync<KeyNotFoundException>();
        }
    }
}
