using AutoFixture;
using Customers_API.Models;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Xunit;

namespace CustomersApi.IntegrationTests
{
    public class CustomersDataSourceTests : BaseCustomerDataSourceTests
    {
        [Fact]
        public async Task CreateCustomerAsync_ValidRequest_CreatesCustomer()
        {
            CreateCustomerRequest createCustomerRequest = new CreateCustomerRequest
            {
                FirstName = this.Fixture.Create<string>(),
                LastName = this.Fixture.Create<string>(),
                BirthDate = this.Fixture.Create<DateTime>(),
                AnnualIncome = this.Fixture.Create<double>()
            };

            Customer expected = new Customer 
             { 
                FirstName = createCustomerRequest.FirstName,
                LastName = createCustomerRequest.LastName,
                BirthDate = createCustomerRequest.BirthDate,
                AnnualIncome = createCustomerRequest.AnnualIncome
            };

            Customer actual = await this.DataSource.CreateCustomerAsync(createCustomerRequest);

            actual.Should().BeEquivalentTo(expected, options => options.Excluding(x => x.Id));

            this.DeleteAllCustomerData();
        }

        [Fact]
        public async Task GetCustomerByIdAsync_ValidCustomerId_ReturnsCustomer()
        {
            var customersToInsert = Fixture.CreateMany<Customer>(1).ToArray();

            this.InsertCustomers(customersToInsert);

            int insertedCustomerId = this.GetAllCustomers().First().Id;

            Customer expected = customersToInsert.First();
            Customer actual = await this.DataSource.GetCustomerByIdAsync(insertedCustomerId);
            
            actual.Should().BeEquivalentTo(expected, options => options.Excluding(x => x.Id).Excluding(x=>x.BirthDate));
            actual.BirthDate.Date.Should().Be(expected.BirthDate.Date);
            this.DeleteAllCustomerData();
        }

        [Fact]
        public async Task GetCustomerByIdAsync_InvalidCustomerId_ReturnsCustomer()
        {
            int customerId = this.Fixture.Create<int>();

            Func<Task> action = () => this.DataSource.GetCustomerByIdAsync(customerId);

            await action.Should().ThrowAsync<KeyNotFoundException>();
        }
    }
}