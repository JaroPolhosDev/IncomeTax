﻿using AutoFixture;
using Customers_API.Contexts;
using Customers_API.DataSource;
using Customers_API.Models;
using System.Data.Entity;
using System.Transactions;

namespace CustomersApi.IntegrationTests
{
    public class BaseCustomerDataSourceTests
    {
        protected readonly CustomerContext CustomerContext;
        protected readonly TransactionScope TransactionScope;
        protected readonly IFixture Fixture;
        protected readonly CustomersDataSource DataSource;
        public BaseCustomerDataSourceTests()
        {
            CustomerContext = new CustomerContext();
            CustomerContext.Database.CreateIfNotExists();
            TransactionScope = new TransactionScope(TransactionScopeOption.RequiresNew);
            Fixture = new Fixture();
            DataSource = new CustomersDataSource();
        }

        public void DeleteAllCustomerData()
        {
           foreach(var customer in CustomerContext.Customers)
            {
                CustomerContext.Customers.Remove(customer);
            }

            CustomerContext.SaveChanges();
        }

        public void InsertCustomers(Customer[] customers)
        {
            foreach(var customer in customers)
            {
                CustomerContext.Customers.Add(customer);
            }
            CustomerContext.SaveChanges();
        }

        public Customer[] GetAllCustomers()
        {
            return CustomerContext.Customers.ToArray();
        }
    }
}
