using AutoFixture;
using FluentAssertions;
using Gateway_API.Clients;
using Gateway_API.Clients.Models;
using Gateway_API.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Gateway_API.Tests.Controller
{
    public class CustomersControllerTests
    {
        private readonly Mock<ICustomersClient> _mockCustomersClient;
        private readonly Mock<ILogger<CustomersController>> _mockLogger;
        private readonly CustomersController _controller;
        private readonly IFixture _fixture;

        public CustomersControllerTests()
        {
            _mockLogger = new Mock<ILogger<CustomersController>>();
            _mockCustomersClient = new Mock<ICustomersClient>();
            _fixture = new Fixture();
            _controller = new CustomersController(_mockLogger.Object, _mockCustomersClient.Object);
        }

        [Fact]
        public async Task CreateCustomerAsync_ValidCustomerDetails_CreatesCustomer()
        {
            CreateCustomerRequestDto request = _fixture.Create<CreateCustomerRequestDto>();

            CustomerDto expectedCustomer = _fixture.Build<CustomerDto>()
                                        .With(x => x.FirstName, request.FirstName)
                                        .With(x => x.LastName, request.LastName)
                                        .With(x => x.BirthDate, request.BirthDate)
                                        .With(x => x.AnnualIncome, request.AnnualIncome)
                                        .Create();

            _mockCustomersClient.Setup(x => x.CreateCustomerAsync(request)).ReturnsAsync(expectedCustomer);

            var result = await _controller.CreateCustomerAsync(request) as ObjectResult;

            result.StatusCode.Should().Be(201);
            result.Value.Should().BeEquivalentTo(expectedCustomer);
        }

        [Fact]
        public async Task CreateCustomerAsync_InvalidCustomerDetails_CreatesCustomer()
        {
            CreateCustomerRequestDto request = _fixture.Create<CreateCustomerRequestDto>();

            _mockCustomersClient.Setup(x => x.CreateCustomerAsync(request)).ThrowsAsync(new KeyNotFoundException());

            Func<Task> action = () => _controller.CreateCustomerAsync(request);

            await action.Should().ThrowAsync<KeyNotFoundException>();
        }

        [Fact]
        public async Task GetCustomerById_ValidCustomerId_ReturnsCustomer()
        {
            var customerId = _fixture.Create<int>();
            var customer = _fixture.Build<CustomerDto>().With(x => x.AnnualIncome, 100).Create();
            double expected = 0;

            _mockCustomersClient.Setup(x => x.GetCustomerByIdAsync(customerId)).ReturnsAsync(customer);

            var result = await _controller.GetCustomerIncomeTaxRatesAsync(customerId) as ObjectResult;

            result.StatusCode.Should().Be(200);
            result.Value.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public async Task GetCustomerById_InvalidCustomerId_ReturnsNotFound()
        {
            var customerId = _fixture.Create<int>();

            _mockCustomersClient.Setup(x => x.GetCustomerByIdAsync(customerId)).ThrowsAsync(new KeyNotFoundException());

            var result = await _controller.GetCustomerIncomeTaxRatesAsync(customerId) as NotFoundResult;

            result.Should().BeOfType<NotFoundResult>();
            result.StatusCode.Should().Be(404);
        }
    }
}