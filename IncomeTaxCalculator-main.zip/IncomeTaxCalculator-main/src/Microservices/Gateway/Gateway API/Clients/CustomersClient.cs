﻿using Gateway_API.Clients.Models;
using System.Text.Json;

namespace Gateway_API.Clients
{
    /// <summary>
    /// Customers Client
    /// </summary>
    public class CustomersClient : ICustomersClient
    {
        private readonly JsonSerializerOptions _options;
        private readonly IHttpClientFactory _clientFactory;

        /// <summary>
        /// Initialises a new instance of <see cref="CustomersClient"/>
        /// </summary>
        /// <param name="clientFactory">Client Factory</param>
        public CustomersClient(IHttpClientFactory clientFactory)
        {
            _options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            _clientFactory = clientFactory;
        }

        /// <summary>
        /// Get customer by id
        /// </summary>
        /// <param name="customerId">Customer Id</param>
        /// <returns>Customer</returns>
        public async Task<CustomerDto> GetCustomerByIdAsync(int customerId)
        {
            var httpClient = _clientFactory.CreateClient();

            var response = await httpClient.GetAsync($"https://localhost:56222/api/Customers/{customerId}", HttpCompletionOption.ResponseContentRead);

            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                throw new KeyNotFoundException();
            }

            var stream = await response.Content.ReadAsStreamAsync();
            var customer = await JsonSerializer.DeserializeAsync<CustomerDto>(stream, _options);

            return customer;
        }

        /// <summary>
        /// Create a new customer
        /// </summary>
        /// <param name="createCustomerRequest">Create Customer Request</param>
        /// <returns>Created Customer</returns>
        public async Task<CustomerDto> CreateCustomerAsync(CreateCustomerRequestDto createCustomerRequest)
        {
            var httpClient = _clientFactory.CreateClient();
   
            var response = await httpClient.PostAsJsonAsync("https://localhost:56222/api/Customers", createCustomerRequest);
            response.EnsureSuccessStatusCode();

            var stream = await response.Content.ReadAsStreamAsync();
            var customer = await JsonSerializer.DeserializeAsync<CustomerDto>(stream, _options);

            return customer;
        }
    }
}
