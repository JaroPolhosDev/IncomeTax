﻿namespace Gateway_API.Clients.Models
{
    /// <summary>
    /// Create Customer Request Dto
    /// </summary>
    public record CreateCustomerRequestDto
    {
        /// <summary>
        /// Customer First Name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Customer Last Name
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Customer Birth Date
        /// </summary>
        public DateTime BirthDate { get; set; }

        /// <summary>
        /// Customer Annual Income
        /// </summary>
        public double AnnualIncome { get; set; }
    }
}
