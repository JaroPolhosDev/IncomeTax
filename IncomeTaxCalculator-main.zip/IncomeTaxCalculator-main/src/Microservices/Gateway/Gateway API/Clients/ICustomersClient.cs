﻿using Gateway_API.Clients.Models;

namespace Gateway_API.Clients
{
    public interface ICustomersClient
    {

        /// <summary>
        /// Create a new customer
        /// </summary>
        /// <param name="createCustomerRequest">Create Customer Request</param>
        /// <returns>Created Customer</returns>
        public Task<CustomerDto> CreateCustomerAsync(CreateCustomerRequestDto createCustomerRequest);

        /// <summary>
        /// Get customer by id
        /// </summary>
        /// <param name="customerId">Customer Id</param>
        /// <returns>Customer</returns>
        public Task<CustomerDto> GetCustomerByIdAsync(int customerId);
    }
}
