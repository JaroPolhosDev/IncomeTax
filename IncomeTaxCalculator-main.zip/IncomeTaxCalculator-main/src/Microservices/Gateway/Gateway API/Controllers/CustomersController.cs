using Gateway_API.Clients;
using Gateway_API.Clients.Models;
using Gateway_API.Helpers;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Gateway_API.Controllers
{
    /// <summary>
    /// Customers Controller
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class CustomersController : ControllerBase
    {
        private readonly ILogger<CustomersController> _logger;
        private readonly ICustomersClient _customersClient;

        /// <summary>
        /// Creates a new intance of <see cref="CustomersController"/>
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="customersClient">Customers Client</param>
        public CustomersController(ILogger<CustomersController> logger, ICustomersClient customersClient)
        {
            _logger = logger;
            _customersClient = customersClient;
        }

        /// <summary>
        /// Create a new customer
        /// </summary>
        /// <param name="createCustomerRequest">Create Custommer Request</param>
        /// <returns>The created <see cref="Customer"/></returns>
        [HttpPost(Name = Routes.CreateCustomer)]
        [ProducesResponseType(typeof(CustomerDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateCustomerAsync([FromBody] CreateCustomerRequestDto createCustomerRequest)
        {
            _logger.LogInformation("Creating a new customer", createCustomerRequest);

            try
            {
                CustomerDto customer = await _customersClient.CreateCustomerAsync(createCustomerRequest);
                _logger.LogInformation($"Customer created: {customer.Id}");
                return this.CreatedAtRoute(Routes.CreateCustomer, customer);
            }
            catch (ValidationException e)
            {
                _logger.LogWarning($"Failed to create a new customer {createCustomerRequest}");
                return this.BadRequest(e);
            }
        }

        /// <summary>
        /// Get a customer income tax rates by the given customer id
        /// </summary>
        /// <param name="customerId">Customer Id</param>
        /// <returns>The customer entity</returns>
        [HttpGet("{customerId}/income-tax", Name = Routes.GetCustomersIncomeTax)]
        [ProducesResponseType(typeof(double), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetCustomerIncomeTaxRatesAsync(int customerId)
        {
            _logger.LogInformation($"Loading customer income tax rates with id: {customerId}");

            try
            {
                CustomerDto customer = await _customersClient.GetCustomerByIdAsync(customerId);
                double incomeTax = MathFunctions.CalculateIncomeTaxForCustomer(customer.AnnualIncome);

                return this.Ok(incomeTax);
            }
            catch (KeyNotFoundException)
            {
                _logger.LogWarning($"Couldn't find a customer with id: {customerId}");
                return this.NotFound($"Couldn't find a customer with id: {customerId}");
            }
        }
    }

    /// <summary>
    /// Routes class
    /// </summary>
    public static class Routes
    {
        /// <summary>
        /// GET "api/customers/{1}/income-tax"
        /// </summary>
        public const string GetCustomersIncomeTax = "Customers.GetCustomerIncomeTax";

        /// <summary>
        /// POST "api/customers"
        /// </summary>
        public const string CreateCustomer = "Customers.CreateCustomer";
    }
}