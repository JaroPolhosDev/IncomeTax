﻿namespace Gateway_API.Helpers
{
    public static class MathFunctions
    {
        public static double CalculateIncomeTaxForCustomer(double annualIncome)
        {
            double incomeTaxValue = 0;

            if(annualIncome <= 0)
            {
                return 0;
            }

            if (annualIncome <= 5000)
            {
                // No tax applicable
                incomeTaxValue = 0;
            }
            else if (annualIncome <= 20000)
            {
                // 20% rate on this income
                incomeTaxValue = (annualIncome - 5000) * 0.20;
            }
            else
            {
                // 40% rate on the rest
                incomeTaxValue = 15000 * 0.20 + (annualIncome - 20000) * 0.40;
            }

            return incomeTaxValue;
        }
    }
}
